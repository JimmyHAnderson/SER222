package edu.ser222.m01_03;


/**
 * CompletedOrderedList represents an implementation of an ordered list that builds on
 * CompletedList.
 *
 * @author (Jimmy Anderson), Acuna
 * @version (1)
 */
public class CompletedOrderedList<T extends Comparable<T>> extends CompletedList<T>
        implements OrderedListADT<T> {
    @Override
    public void add(T element) throws NullPointerException {
        //Checking to see if the element is null, if it is null then we will return a NullPointerException
        if (element == null) {
            throw new NullPointerException("null element lil bro");
        }

        DoubleLinearNode<T> newNode = new DoubleLinearNode<>(element, null, null);
        //this checks to see if the nodes are empty, if it is empty then we will initialize a new head and tail
        if (isEmpty()) {
            head = newNode;
            tail = newNode;
        }
        //if it isn't empty, then we will set the current node to head
        else {
            DoubleLinearNode<T> curNode = head;
            //We will use a while loop in case we don't know the amount of elements and as long as it's not null we will insert it at the beginning
            // Traverse the list to find the correct position for the new node
            while (curNode != null) {
                if (element.compareTo(curNode.getNode()) <= 0) {
                    if (curNode == head) {
                        newNode.setNext(head);
                        head.setPrevious(newNode);
                        head = newNode;
                    }
                    //in the case where we want to add in between nodes
                    else {
                        newNode.setNext(curNode);
                        newNode.setPrevious(curNode.getPrevious());
                        curNode.getPrevious().setNext(newNode);
                        curNode.setPrevious(newNode);
                    }
                    count++;
                    modChange++;
                    return;
                }
                //in the case where we want to add at the tail

                else if (curNode.getNext() == null) {
                    curNode.setNext(newNode);
                    newNode.setPrevious(curNode);
                    tail = newNode;
                    count++;
                    modChange++;
                    return;
                }
                curNode = curNode.getNext();
            }
        }
        count++;
        modChange++;
    }
}
